﻿function toggleMobileSearch() {
    const search = document.getElementById('mobileSearchForm');
    search.classList.toggle('show');
}
